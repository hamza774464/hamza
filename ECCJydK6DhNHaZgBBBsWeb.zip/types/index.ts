// OrangePay Type Definitions

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  balance: number;
  currency: string;
  avatar?: string;
}

export interface Transaction {
  id: string;
  type: 'send' | 'receive' | 'bill' | 'package' | 'qr' | 'exchange' | 'purchase';
  amount: number;
  currency: string;
  recipient?: string;
  sender?: string;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  timestamp: Date;
  category?: string;
  aiInsights?: string;
}

export interface Bill {
  id: string;
  type: 'water' | 'electricity' | 'gas' | 'internet' | 'phone';
  provider: string;
  accountNumber: string;
  amount: number;
  dueDate: Date;
  status: 'paid' | 'pending' | 'overdue';
}

export interface Package {
  id: string;
  name: string;
  provider: string;
  price: number;
  duration: string;
  description: string;
  type: 'internet' | 'mobile' | 'tv';
}

export interface Currency {
  code: string;
  name: string;
  symbol: string;
  rate: number;
  flag: string;
}

export interface AIInsight {
  id: string;
  type: 'expense' | 'threat' | 'recommendation';
  title: string;
  description: string;
  severity?: 'low' | 'medium' | 'high';
  timestamp: Date;
}

export interface Card {
  id: string;
  number: string;
  holder: string;
  expiry: string;
  cvv: string;
  type: 'virtual' | 'physical';
  encrypted: boolean;
}
