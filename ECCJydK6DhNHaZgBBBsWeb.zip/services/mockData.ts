import { User, Transaction, Bill, Package, Currency, AIInsight, Card } from '../types';

export const mockUser: User = {
  id: '1',
  name: 'محمد أحمد',
  email: 'mohammed@orangepay.com',
  phone: '+966501234567',
  balance: 45750.00,
  currency: 'SAR',
  avatar: undefined,
};

export const mockCard: Card = {
  id: 'card-1',
  number: '4532 **** **** 8765',
  holder: 'MOHAMMED AHMED',
  expiry: '12/27',
  cvv: '***',
  type: 'virtual',
  encrypted: true,
};

export const mockTransactions: Transaction[] = [
  {
    id: 't1',
    type: 'receive',
    amount: 2500.00,
    currency: 'SAR',
    sender: 'علي محمود',
    description: 'تحويل من علي',
    status: 'completed',
    timestamp: new Date(Date.now() - 3600000),
    aiInsights: 'تحويل منتظم من علي محمود',
  },
  {
    id: 't2',
    type: 'bill',
    amount: -350.00,
    currency: 'SAR',
    description: 'فاتورة كهرباء',
    status: 'completed',
    timestamp: new Date(Date.now() - 7200000),
    category: 'utilities',
  },
  {
    id: 't3',
    type: 'send',
    amount: -1200.00,
    currency: 'SAR',
    recipient: 'فاطمة حسن',
    description: 'تحويل إلى فاطمة',
    status: 'completed',
    timestamp: new Date(Date.now() - 86400000),
  },
  {
    id: 't4',
    type: 'package',
    amount: -199.00,
    currency: 'SAR',
    description: 'باقة إنترنت - STC',
    status: 'completed',
    timestamp: new Date(Date.now() - 172800000),
    category: 'subscriptions',
  },
  {
    id: 't5',
    type: 'qr',
    amount: -85.00,
    currency: 'SAR',
    description: 'دفع QR - مطعم الأصالة',
    status: 'completed',
    timestamp: new Date(Date.now() - 259200000),
    category: 'food',
  },
];

export const mockBills: Bill[] = [
  {
    id: 'b1',
    type: 'electricity',
    provider: 'الشركة السعودية للكهرباء',
    accountNumber: '123456789',
    amount: 450.00,
    dueDate: new Date(Date.now() + 604800000),
    status: 'pending',
  },
  {
    id: 'b2',
    type: 'water',
    provider: 'المياه الوطنية',
    accountNumber: '987654321',
    amount: 120.00,
    dueDate: new Date(Date.now() + 1209600000),
    status: 'pending',
  },
  {
    id: 'b3',
    type: 'internet',
    provider: 'STC',
    accountNumber: '555123456',
    amount: 299.00,
    dueDate: new Date(Date.now() + 259200000),
    status: 'pending',
  },
];

export const mockPackages: Package[] = [
  {
    id: 'p1',
    name: 'باقة الإنترنت المنزلي 200 ميجا',
    provider: 'STC',
    price: 299.00,
    duration: 'شهري',
    description: 'سرعة تصل إلى 200 ميجا بت/ثانية',
    type: 'internet',
  },
  {
    id: 'p2',
    name: 'باقة الجوال - 100 جيجا',
    provider: 'موبايلي',
    price: 150.00,
    duration: 'شهري',
    description: '100 جيجا إنترنت + مكالمات لا محدودة',
    type: 'mobile',
  },
  {
    id: 'p3',
    name: 'باقة OSN الترفيهية',
    provider: 'OSN',
    price: 199.00,
    duration: 'شهري',
    description: 'أفلام ومسلسلات حصرية',
    type: 'tv',
  },
];

export const mockCurrencies: Currency[] = [
  { code: 'SAR', name: 'ريال سعودي', symbol: 'ر.س', rate: 1.00, flag: '🇸🇦' },
  { code: 'USD', name: 'دولار أمريكي', symbol: '$', rate: 3.75, flag: '🇺🇸' },
  { code: 'EUR', name: 'يورو', symbol: '€', rate: 4.10, flag: '🇪🇺' },
  { code: 'GBP', name: 'جنيه إسترليني', symbol: '£', rate: 4.75, flag: '🇬🇧' },
  { code: 'AED', name: 'درهم إماراتي', symbol: 'د.إ', rate: 1.02, flag: '🇦🇪' },
];

export const mockAIInsights: AIInsight[] = [
  {
    id: 'ai1',
    type: 'expense',
    title: 'توفير محتمل',
    description: 'لاحظنا أن إنفاقك على المطاعم زاد 30% هذا الشهر. يمكنك توفير 500 ريال شهرياً.',
    timestamp: new Date(Date.now() - 3600000),
  },
  {
    id: 'ai2',
    type: 'threat',
    title: 'تنبيه أمني',
    description: 'تم رصد محاولة دخول مشبوهة من جهاز غير معروف. تم حظرها تلقائياً.',
    severity: 'high',
    timestamp: new Date(Date.now() - 7200000),
  },
  {
    id: 'ai3',
    type: 'recommendation',
    title: 'توصية ذكية',
    description: 'بناءً على نمط إنفاقك، ننصحك بباقة إنترنت أعلى لتوفير 15% شهرياً.',
    timestamp: new Date(Date.now() - 86400000),
  },
];
