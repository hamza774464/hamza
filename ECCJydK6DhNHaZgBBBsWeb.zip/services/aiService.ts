import { Transaction, AIInsight } from '../types';

export class AIService {
  /**
   * Analyze spending patterns using AI
   */
  static analyzeExpenses(transactions: Transaction[]): AIInsight[] {
    const insights: AIInsight[] = [];
    
    // Calculate category spending
    const categorySpending: { [key: string]: number } = {};
    transactions.forEach(t => {
      if (t.amount < 0 && t.category) {
        categorySpending[t.category] = (categorySpending[t.category] || 0) + Math.abs(t.amount);
      }
    });
    
    // Find highest spending category
    const highestCategory = Object.entries(categorySpending)
      .sort(([, a], [, b]) => b - a)[0];
    
    if (highestCategory && highestCategory[1] > 1000) {
      insights.push({
        id: `ai-${Date.now()}-1`,
        type: 'expense',
        title: 'تحليل الإنفاق',
        description: `أعلى إنفاق لك في فئة ${this.translateCategory(highestCategory[0])} بمبلغ ${highestCategory[1].toFixed(2)} ريال`,
        timestamp: new Date(),
      });
    }
    
    return insights;
  }
  
  /**
   * Detect suspicious activities
   */
  static detectThreats(transactions: Transaction[]): AIInsight[] {
    const threats: AIInsight[] = [];
    
    // Check for unusual transaction amounts
    const amounts = transactions.map(t => Math.abs(t.amount));
    const avgAmount = amounts.reduce((a, b) => a + b, 0) / amounts.length;
    
    transactions.forEach(t => {
      if (Math.abs(t.amount) > avgAmount * 5) {
        threats.push({
          id: `threat-${t.id}`,
          type: 'threat',
          title: 'تحويل غير معتاد',
          description: `تم رصد تحويل بمبلغ ${Math.abs(t.amount)} ريال - أعلى من المعتاد`,
          severity: 'medium',
          timestamp: new Date(),
        });
      }
    });
    
    return threats;
  }
  
  /**
   * Generate smart recommendations
   */
  static generateRecommendations(transactions: Transaction[]): AIInsight[] {
    const recommendations: AIInsight[] = [];
    
    // Analyze bill payments
    const billPayments = transactions.filter(t => t.type === 'bill');
    if (billPayments.length > 3) {
      recommendations.push({
        id: `rec-${Date.now()}`,
        type: 'recommendation',
        title: 'توصية ذكية',
        description: 'يمكنك توفير الوقت بتفعيل الدفع التلقائي للفواتير',
        timestamp: new Date(),
      });
    }
    
    return recommendations;
  }
  
  /**
   * Predict future expenses
   */
  static predictExpenses(transactions: Transaction[]): number {
    const expenses = transactions
      .filter(t => t.amount < 0)
      .map(t => Math.abs(t.amount));
    
    if (expenses.length === 0) return 0;
    
    const avgExpense = expenses.reduce((a, b) => a + b, 0) / expenses.length;
    return avgExpense * 30; // Monthly prediction
  }
  
  /**
   * Categorize transaction automatically
   */
  static categorizeTransaction(description: string): string {
    const keywords: { [key: string]: string[] } = {
      food: ['مطعم', 'كافيه', 'بيتزا', 'طعام'],
      utilities: ['كهرباء', 'ماء', 'غاز'],
      subscriptions: ['باقة', 'اشتراك'],
      shopping: ['متجر', 'سوق', 'شراء'],
      transport: ['أوبر', 'كريم', 'بنزين'],
    };
    
    for (const [category, words] of Object.entries(keywords)) {
      if (words.some(word => description.includes(word))) {
        return category;
      }
    }
    
    return 'other';
  }
  
  private static translateCategory(category: string): string {
    const translations: { [key: string]: string } = {
      food: 'الطعام',
      utilities: 'المرافق',
      subscriptions: 'الاشتراكات',
      shopping: 'التسوق',
      transport: 'المواصلات',
      other: 'أخرى',
    };
    return translations[category] || category;
  }
}
