import { useState, useEffect } from 'react';
import { Transaction } from '../types';
import { mockTransactions } from '../services/mockData';
import { AIService } from '../services/aiService';

export function useTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions);
  const [loading, setLoading] = useState(false);
  
  const addTransaction = (transaction: Omit<Transaction, 'id' | 'timestamp' | 'aiInsights'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: `t${Date.now()}`,
      timestamp: new Date(),
      category: AIService.categorizeTransaction(transaction.description),
      aiInsights: `معاملة ${transaction.type === 'send' ? 'صادرة' : 'واردة'} بمبلغ ${Math.abs(transaction.amount)} ${transaction.currency}`,
    };
    
    setTransactions(prev => [newTransaction, ...prev]);
    return newTransaction;
  };
  
  const getRecentTransactions = (limit: number = 5) => {
    return transactions.slice(0, limit);
  };
  
  const getTransactionsByType = (type: Transaction['type']) => {
    return transactions.filter(t => t.type === type);
  };
  
  const getTotalSpent = () => {
    return transactions
      .filter(t => t.amount < 0)
      .reduce((sum, t) => sum + Math.abs(t.amount), 0);
  };
  
  const getTotalReceived = () => {
    return transactions
      .filter(t => t.amount > 0)
      .reduce((sum, t) => sum + t.amount, 0);
  };
  
  return {
    transactions,
    loading,
    addTransaction,
    getRecentTransactions,
    getTransactionsByType,
    getTotalSpent,
    getTotalReceived,
  };
}
