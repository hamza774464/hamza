import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import { Transaction } from '../../types';

interface TransactionItemProps {
  transaction: Transaction;
  onPress?: () => void;
}

export function TransactionItem({ transaction, onPress }: TransactionItemProps) {
  const getIcon = () => {
    const iconMap: Record<Transaction['type'], keyof typeof MaterialIcons.glyphMap> = {
      send: 'north-east',
      receive: 'south-west',
      bill: 'receipt',
      package: 'card-giftcard',
      qr: 'qr-code-scanner',
      exchange: 'currency-exchange',
      purchase: 'shopping-cart',
    };
    return iconMap[transaction.type];
  };
  
  const getIconColor = () => {
    if (transaction.amount > 0) return Colors.success;
    return Colors.primary.main;
  };
  
  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours < 1) return 'الآن';
    if (hours < 24) return `منذ ${hours} ساعة`;
    const days = Math.floor(hours / 24);
    return `منذ ${days} يوم`;
  };
  
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={[styles.iconContainer, { backgroundColor: `${getIconColor()}15` }]}>
        <MaterialIcons name={getIcon()} size={24} color={getIconColor()} />
      </View>
      
      <View style={styles.content}>
        <Text style={styles.description} numberOfLines={1}>
          {transaction.description}
        </Text>
        <Text style={styles.time}>{formatDate(transaction.timestamp)}</Text>
      </View>
      
      <View style={styles.amountContainer}>
        <Text style={[
          styles.amount,
          { color: transaction.amount > 0 ? Colors.success : Colors.light.text }
        ]}>
          {transaction.amount > 0 ? '+' : ''}{transaction.amount.toFixed(2)}
        </Text>
        <Text style={styles.currency}>{transaction.currency}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.md,
    gap: Spacing.md,
  },
  
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  content: {
    flex: 1,
    gap: 4,
  },
  
  description: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.medium,
    color: Colors.light.text,
  },
  
  time: {
    fontSize: Typography.caption,
    color: Colors.light.textSecondary,
  },
  
  amountContainer: {
    alignItems: 'flex-end',
  },
  
  amount: {
    fontSize: Typography.h6,
    fontWeight: Typography.weight.bold,
  },
  
  currency: {
    fontSize: Typography.caption,
    color: Colors.light.textSecondary,
  },
});
