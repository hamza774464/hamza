import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, BorderRadius, Spacing, Shadows } from '../../constants/theme';
import { Card as CardType } from '../../types';
import { EncryptionService } from '../../services/encryption';

interface VirtualCardProps {
  card: CardType;
}

export function VirtualCard({ card }: VirtualCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  return (
    <LinearGradient
      colors={['#E65100', '#FF6D00', '#FF8F00']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.card}
    >
      {/* Security Badge */}
      <View style={styles.header}>
        <View style={styles.securityBadge}>
          <MaterialIcons name="verified-user" size={16} color={Colors.light.background} />
          <Text style={styles.securityText}>تشفير 256-بت</Text>
        </View>
        <MaterialIcons name="contactless" size={32} color={Colors.light.background} />
      </View>
      
      {/* Card Number */}
      <View style={styles.numberContainer}>
        <Text style={styles.cardNumber}>{card.number}</Text>
      </View>
      
      {/* Card Details */}
      <View style={styles.footer}>
        <View>
          <Text style={styles.label}>حامل البطاقة</Text>
          <Text style={styles.value}>{card.holder}</Text>
        </View>
        
        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <Text style={styles.label}>تاريخ الانتهاء</Text>
            <Text style={styles.value}>{card.expiry}</Text>
          </View>
          
          <TouchableOpacity
            onPress={() => setShowDetails(!showDetails)}
            style={styles.cvvContainer}
          >
            <Text style={styles.label}>CVV</Text>
            <View style={styles.cvvRow}>
              <Text style={styles.value}>{showDetails ? '123' : card.cvv}</Text>
              <MaterialIcons
                name={showDetails ? 'visibility-off' : 'visibility'}
                size={16}
                color={Colors.light.background}
              />
            </View>
          </TouchableOpacity>
        </View>
      </View>
      
      {/* Chip */}
      <View style={styles.chip}>
        <MaterialIcons name="credit-card" size={24} color="#FFD700" />
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    height: 200,
    ...Shadows.orange,
  },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  
  securityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    gap: 4,
  },
  
  securityText: {
    fontSize: Typography.caption,
    color: Colors.light.background,
    fontWeight: Typography.weight.medium,
  },
  
  numberContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  
  cardNumber: {
    fontSize: 22,
    fontWeight: Typography.weight.bold,
    color: Colors.light.background,
    letterSpacing: 2,
  },
  
  footer: {
    gap: Spacing.sm,
  },
  
  detailsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  
  detailItem: {
    gap: 4,
  },
  
  cvvContainer: {
    gap: 4,
  },
  
  cvvRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  
  label: {
    fontSize: Typography.caption,
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: Typography.weight.medium,
  },
  
  value: {
    fontSize: Typography.body1,
    color: Colors.light.background,
    fontWeight: Typography.weight.semibold,
  },
  
  chip: {
    position: 'absolute',
    top: Spacing.lg,
    left: Spacing.lg,
    width: 48,
    height: 38,
    backgroundColor: 'rgba(255, 215, 0, 0.3)',
    borderRadius: BorderRadius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
