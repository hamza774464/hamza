import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, BorderRadius, Spacing, Shadows } from '../../constants/theme';
import { AIInsight } from '../../types';
import { LinearGradient } from 'expo-linear-gradient';

interface AIInsightCardProps {
  insight: AIInsight;
}

export function AIInsightCard({ insight }: AIInsightCardProps) {
  const getIcon = () => {
    const iconMap: Record<AIInsight['type'], keyof typeof MaterialIcons.glyphMap> = {
      expense: 'insights',
      threat: 'security',
      recommendation: 'lightbulb',
    };
    return iconMap[insight.type];
  };
  
  const getGradient = () => {
    if (insight.type === 'threat') {
      return insight.severity === 'high' 
        ? ['#D32F2F', '#F44336'] 
        : ['#FFB300', '#FFC107'];
    }
    if (insight.type === 'recommendation') {
      return ['#7C4DFF', '#9C27B0'];
    }
    return ['#00C853', '#4CAF50'];
  };
  
  return (
    <View style={styles.container}>
      <LinearGradient
        colors={getGradient()}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.iconContainer}
      >
        <MaterialIcons name={getIcon()} size={24} color={Colors.light.background} />
      </LinearGradient>
      
      <View style={styles.content}>
        <Text style={styles.title}>{insight.title}</Text>
        <Text style={styles.description}>{insight.description}</Text>
      </View>
      
      {insight.severity && (
        <View style={[
          styles.badge,
          { backgroundColor: insight.severity === 'high' ? Colors.error : Colors.warning }
        ]}>
          <Text style={styles.badgeText}>
            {insight.severity === 'high' ? 'عالي' : 'متوسط'}
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: Spacing.md,
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.lg,
    gap: Spacing.md,
    ...Shadows.sm,
  },
  
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  content: {
    flex: 1,
    gap: 4,
  },
  
  title: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  description: {
    fontSize: Typography.body2,
    color: Colors.light.textSecondary,
    lineHeight: Typography.body2 * Typography.lineHeight.normal,
  },
  
  badge: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
  },
  
  badgeText: {
    fontSize: Typography.caption,
    fontWeight: Typography.weight.bold,
    color: Colors.light.background,
  },
});
