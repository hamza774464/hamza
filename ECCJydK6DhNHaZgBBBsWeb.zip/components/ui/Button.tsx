import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, ViewStyle, TextStyle } from 'react-native';
import { Colors, Typography, BorderRadius, Spacing, Shadows } from '../../constants/theme';
import { LinearGradient } from 'expo-linear-gradient';

interface ButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'gradient';
  size?: 'small' | 'medium' | 'large';
  loading?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  style?: ViewStyle;
}

export function Button({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  loading = false,
  disabled = false,
  icon,
  style,
}: ButtonProps) {
  const buttonStyle = [
    styles.button,
    styles[size],
    variant !== 'gradient' && styles[variant],
    disabled && styles.disabled,
    style,
  ];
  
  const textStyle = [
    styles.text,
    styles[`${size}Text` as keyof typeof styles] as TextStyle,
    variant === 'outline' && styles.outlineText,
  ];
  
  if (variant === 'gradient') {
    return (
      <TouchableOpacity
        onPress={onPress}
        disabled={disabled || loading}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={Colors.primary.gradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={buttonStyle}
        >
          {loading ? (
            <ActivityIndicator color={Colors.light.background} />
          ) : (
            <>
              {icon}
              <Text style={textStyle}>{title}</Text>
            </>
          )}
        </LinearGradient>
      </TouchableOpacity>
    );
  }
  
  return (
    <TouchableOpacity
      style={buttonStyle}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator color={variant === 'outline' ? Colors.primary.main : Colors.light.background} />
      ) : (
        <>
          {icon}
          <Text style={textStyle}>{title}</Text>
        </>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: BorderRadius.md,
    gap: Spacing.sm,
  },
  
  // Sizes
  small: {
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  medium: {
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },
  large: {
    paddingVertical: Spacing.lg,
    paddingHorizontal: Spacing.xl,
  },
  
  // Variants
  primary: {
    backgroundColor: Colors.primary.main,
    ...Shadows.orange,
  },
  secondary: {
    backgroundColor: Colors.light.surfaceElevated,
  },
  outline: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: Colors.primary.main,
  },
  
  disabled: {
    opacity: 0.5,
  },
  
  // Text Styles
  text: {
    fontWeight: Typography.weight.semibold,
    color: Colors.light.background,
  },
  smallText: {
    fontSize: Typography.body2,
  },
  mediumText: {
    fontSize: Typography.button,
  },
  largeText: {
    fontSize: Typography.h6,
  },
  outlineText: {
    color: Colors.primary.main,
  },
});
