import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Colors, BorderRadius, Spacing, Shadows } from '../../constants/theme';
import { LinearGradient } from 'expo-linear-gradient';

interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'glass' | 'gradient';
  style?: ViewStyle;
}

export function Card({ children, variant = 'default', style }: CardProps) {
  if (variant === 'gradient') {
    return (
      <LinearGradient
        colors={Colors.light.cardGradient}
        style={[styles.card, style]}
      >
        {children}
      </LinearGradient>
    );
  }
  
  if (variant === 'glass') {
    return (
      <View style={[styles.card, styles.glass, style]}>
        {children}
      </View>
    );
  }
  
  return (
    <View style={[styles.card, styles.default, style]}>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
  },
  
  default: {
    backgroundColor: Colors.light.surfaceElevated,
    ...Shadows.md,
  },
  
  glass: {
    backgroundColor: Colors.light.glass,
    borderWidth: 1,
    borderColor: 'rgba(230, 81, 0, 0.2)',
    ...Shadows.sm,
  },
});
