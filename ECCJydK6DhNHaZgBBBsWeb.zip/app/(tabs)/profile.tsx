import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius, Shadows } from '../../constants/theme';
import { Card } from '../../components/ui/Card';
import { mockUser } from '../../services/mockData';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  
  const menuItems = [
    { icon: 'account-circle', label: 'معلومات الحساب', route: '/account' },
    { icon: 'credit-card', label: 'بطاقاتي', route: '/cards' },
    { icon: 'lock', label: 'الأمان والخصوصية', route: '/security' },
    { icon: 'notifications', label: 'الإشعارات', route: '/notifications' },
    { icon: 'language', label: 'اللغة', route: '/language' },
    { icon: 'help', label: 'المساعدة والدعم', route: '/support' },
    { icon: 'info', label: 'حول التطبيق', route: '/about' },
  ];
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {/* Profile Header */}
        <LinearGradient
          colors={Colors.primary.gradient}
          style={styles.profileHeader}
        >
          <View style={styles.avatarContainer}>
            <MaterialIcons name="account-circle" size={80} color={Colors.light.background} />
          </View>
          <Text style={styles.userName}>{mockUser.name}</Text>
          <Text style={styles.userEmail}>{mockUser.email}</Text>
          <Text style={styles.userPhone}>{mockUser.phone}</Text>
        </LinearGradient>
        
        {/* Security Badge */}
        <Card variant="glass" style={styles.securityCard}>
          <View style={styles.securityRow}>
            <View style={styles.securityInfo}>
              <MaterialIcons name="verified-user" size={32} color={Colors.success} />
              <View>
                <Text style={styles.securityTitle}>حساب محمي</Text>
                <Text style={styles.securityDesc}>مستوى الأمان: ممتاز</Text>
              </View>
            </View>
            <MaterialIcons name="chevron-left" size={24} color={Colors.light.textSecondary} />
          </View>
        </Card>
        
        {/* Menu Items */}
        <View style={styles.menu}>
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={styles.menuItem}
              activeOpacity={0.7}
            >
              <View style={styles.menuItemLeft}>
                <View style={[styles.menuIcon, { backgroundColor: `${Colors.primary.main}15` }]}>
                  <MaterialIcons name={item.icon as any} size={24} color={Colors.primary.main} />
                </View>
                <Text style={styles.menuLabel}>{item.label}</Text>
              </View>
              <MaterialIcons name="chevron-left" size={24} color={Colors.light.textSecondary} />
            </TouchableOpacity>
          ))}
        </View>
        
        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutButton}>
          <MaterialIcons name="logout" size={24} color={Colors.error} />
          <Text style={styles.logoutText}>تسجيل الخروج</Text>
        </TouchableOpacity>
        
        {/* Version */}
        <Text style={styles.version}>الإصدار 1.0.0</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  
  content: {
    padding: Spacing.md,
    gap: Spacing.lg,
  },
  
  profileHeader: {
    alignItems: 'center',
    padding: Spacing.xl,
    borderRadius: BorderRadius.xl,
    gap: Spacing.sm,
    ...Shadows.orange,
  },
  
  avatarContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  
  userName: {
    fontSize: Typography.h4,
    fontWeight: Typography.weight.bold,
    color: Colors.light.background,
  },
  
  userEmail: {
    fontSize: Typography.body2,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  
  userPhone: {
    fontSize: Typography.body2,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  
  securityCard: {
    padding: Spacing.lg,
  },
  
  securityRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  
  securityInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  
  securityTitle: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  securityDesc: {
    fontSize: Typography.caption,
    color: Colors.success,
  },
  
  menu: {
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.lg,
    overflow: 'hidden',
  },
  
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light.border,
  },
  
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
  },
  
  menuIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  menuLabel: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.medium,
    color: Colors.light.text,
  },
  
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    padding: Spacing.md,
    backgroundColor: `${Colors.error}15`,
    borderRadius: BorderRadius.md,
  },
  
  logoutText: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.semibold,
    color: Colors.error,
  },
  
  version: {
    fontSize: Typography.caption,
    color: Colors.light.textSecondary,
    textAlign: 'center',
  },
});
