import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import { TransactionItem } from '../../components/feature/TransactionItem';
import { useTransactions } from '../../hooks/useTransactions';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

export default function TransactionsScreen() {
  const insets = useSafeAreaInsets();
  const { transactions, getTotalSpent, getTotalReceived } = useTransactions();
  const [filter, setFilter] = useState<'all' | 'sent' | 'received'>('all');
  
  const filteredTransactions = transactions.filter(t => {
    if (filter === 'sent') return t.amount < 0;
    if (filter === 'received') return t.amount > 0;
    return true;
  });
  
  const filters = [
    { key: 'all' as const, label: 'الكل' },
    { key: 'sent' as const, label: 'المرسل' },
    { key: 'received' as const, label: 'المستلم' },
  ];
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>المعاملات</Text>
        <TouchableOpacity>
          <MaterialIcons name="filter-list" size={24} color={Colors.primary.main} />
        </TouchableOpacity>
      </View>
      
      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={[styles.statCard, { backgroundColor: `${Colors.success}15` }]}>
          <MaterialIcons name="south-west" size={24} color={Colors.success} />
          <Text style={styles.statLabel}>إجمالي المستلم</Text>
          <Text style={[styles.statValue, { color: Colors.success }]}>
            {getTotalReceived().toFixed(2)} ر.س
          </Text>
        </View>
        
        <View style={[styles.statCard, { backgroundColor: `${Colors.primary.main}15` }]}>
          <MaterialIcons name="north-east" size={24} color={Colors.primary.main} />
          <Text style={styles.statLabel}>إجمالي المرسل</Text>
          <Text style={[styles.statValue, { color: Colors.primary.main }]}>
            {getTotalSpent().toFixed(2)} ر.س
          </Text>
        </View>
      </View>
      
      {/* Filters */}
      <View style={styles.filtersContainer}>
        {filters.map(f => (
          <TouchableOpacity
            key={f.key}
            style={[
              styles.filterButton,
              filter === f.key && styles.filterButtonActive
            ]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={[
              styles.filterText,
              filter === f.key && styles.filterTextActive
            ]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      {/* Transactions List */}
      <ScrollView
        style={styles.list}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
      >
        {filteredTransactions.map(transaction => (
          <TransactionItem
            key={transaction.id}
            transaction={transaction}
            onPress={() => {}}
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.lg,
  },
  
  title: {
    fontSize: Typography.h3,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  statsContainer: {
    flexDirection: 'row',
    gap: Spacing.md,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.lg,
  },
  
  statCard: {
    flex: 1,
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    gap: Spacing.xs,
  },
  
  statLabel: {
    fontSize: Typography.caption,
    color: Colors.light.textSecondary,
  },
  
  statValue: {
    fontSize: Typography.h6,
    fontWeight: Typography.weight.bold,
  },
  
  filtersContainer: {
    flexDirection: 'row',
    gap: Spacing.sm,
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.md,
  },
  
  filterButton: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.light.surfaceElevated,
  },
  
  filterButtonActive: {
    backgroundColor: Colors.primary.main,
  },
  
  filterText: {
    fontSize: Typography.body2,
    fontWeight: Typography.weight.medium,
    color: Colors.light.textSecondary,
  },
  
  filterTextActive: {
    color: Colors.light.background,
  },
  
  list: {
    flex: 1,
  },
  
  listContent: {
    padding: Spacing.md,
    gap: Spacing.sm,
  },
});
