import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import { VirtualCard } from '../../components/feature/VirtualCard';
import { QuickAction } from '../../components/feature/QuickAction';
import { TransactionItem } from '../../components/feature/TransactionItem';
import { mockUser, mockCard } from '../../services/mockData';
import { useTransactions } from '../../hooks/useTransactions';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { getRecentTransactions } = useTransactions();
  const recentTransactions = getRecentTransactions(5);
  
  const quickActions = [
    { icon: 'send' as const, label: 'إرسال', route: '/send' },
    { icon: 'account-balance-wallet' as const, label: 'استلام', route: '/receive' },
    { icon: 'receipt' as const, label: 'فواتير', route: '/bills' },
    { icon: 'card-giftcard' as const, label: 'باقات', route: '/packages' },
    { icon: 'currency-exchange' as const, label: 'صرف', route: '/exchange' },
  ];
  
  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top }]}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>مرحباً بك</Text>
          <Text style={styles.userName}>{mockUser.name}</Text>
        </View>
        <TouchableOpacity style={styles.notificationButton}>
          <MaterialIcons name="notifications" size={24} color={Colors.primary.main} />
          <View style={styles.badge} />
        </TouchableOpacity>
      </View>
      
      {/* Balance Card */}
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>الرصيد المتاح</Text>
        <View style={styles.balanceRow}>
          <Text style={styles.balanceAmount}>
            {mockUser.balance.toLocaleString('ar-SA', { minimumFractionDigits: 2 })}
          </Text>
          <Text style={styles.balanceCurrency}>{mockUser.currency}</Text>
        </View>
        <TouchableOpacity style={styles.eyeButton}>
          <MaterialIcons name="visibility" size={20} color={Colors.light.textSecondary} />
        </TouchableOpacity>
      </View>
      
      {/* Virtual Card */}
      <View style={styles.section}>
        <VirtualCard card={mockCard} />
      </View>
      
      {/* Quick Actions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>العمليات السريعة</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.quickActions}
        >
          {quickActions.map((action, index) => (
            <QuickAction
              key={index}
              icon={action.icon}
              label={action.label}
              onPress={() => {}}
            />
          ))}
        </ScrollView>
      </View>
      
      {/* Recent Transactions */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>المعاملات الأخيرة</Text>
          <TouchableOpacity onPress={() => router.push('/transactions')}>
            <Text style={styles.seeAll}>عرض الكل</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.transactionsList}>
          {recentTransactions.map((transaction) => (
            <TransactionItem
              key={transaction.id}
              transaction={transaction}
              onPress={() => {}}
            />
          ))}
        </View>
      </View>
      
      {/* Security Notice */}
      <View style={styles.securityNotice}>
        <MaterialIcons name="verified-user" size={20} color={Colors.success} />
        <Text style={styles.securityText}>
          جميع معاملاتك محمية بتشفير 256-بت من الدرجة العسكرية
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.lg,
  },
  
  greeting: {
    fontSize: Typography.body2,
    color: Colors.light.textSecondary,
  },
  
  userName: {
    fontSize: Typography.h3,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  notificationButton: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.light.surfaceElevated,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  badge: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.error,
  },
  
  balanceCard: {
    marginHorizontal: Spacing.md,
    padding: Spacing.lg,
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.xl,
    marginBottom: Spacing.lg,
  },
  
  balanceLabel: {
    fontSize: Typography.body2,
    color: Colors.light.textSecondary,
    marginBottom: Spacing.sm,
  },
  
  balanceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: Spacing.sm,
  },
  
  balanceAmount: {
    fontSize: 36,
    fontWeight: Typography.weight.bold,
    color: Colors.primary.main,
  },
  
  balanceCurrency: {
    fontSize: Typography.h5,
    color: Colors.light.textSecondary,
  },
  
  eyeButton: {
    position: 'absolute',
    top: Spacing.lg,
    left: Spacing.lg,
  },
  
  section: {
    paddingHorizontal: Spacing.md,
    marginBottom: Spacing.lg,
  },
  
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  
  sectionTitle: {
    fontSize: Typography.h5,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  seeAll: {
    fontSize: Typography.body2,
    color: Colors.primary.main,
    fontWeight: Typography.weight.medium,
  },
  
  quickActions: {
    gap: Spacing.md,
    paddingVertical: Spacing.sm,
  },
  
  transactionsList: {
    gap: Spacing.sm,
  },
  
  securityNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.xl,
    padding: Spacing.md,
    backgroundColor: `${Colors.success}15`,
    borderRadius: BorderRadius.md,
  },
  
  securityText: {
    flex: 1,
    fontSize: Typography.caption,
    color: Colors.success,
    fontWeight: Typography.weight.medium,
  },
});
