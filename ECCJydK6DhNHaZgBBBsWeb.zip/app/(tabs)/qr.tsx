import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Modal } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius, Shadows } from '../../constants/theme';
import { Button } from '../../components/ui/Button';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

export default function QRScreen() {
  const insets = useSafeAreaInsets();
  const [mode, setMode] = useState<'scan' | 'show'>('scan');
  const [amount, setAmount] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  
  const handleScan = () => {
    // Simulate scan success
    setTimeout(() => {
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    }, 1500);
  };
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>الدفع عبر QR</Text>
        <View style={styles.modeSwitch}>
          <TouchableOpacity
            style={[styles.modeButton, mode === 'scan' && styles.modeButtonActive]}
            onPress={() => setMode('scan')}
          >
            <Text style={[styles.modeText, mode === 'scan' && styles.modeTextActive]}>
              مسح
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.modeButton, mode === 'show' && styles.modeButtonActive]}
            onPress={() => setMode('show')}
          >
            <Text style={[styles.modeText, mode === 'show' && styles.modeTextActive]}>
              عرض
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {mode === 'scan' ? (
        <View style={styles.content}>
          {/* QR Scanner Frame */}
          <View style={styles.scannerContainer}>
            <View style={styles.scannerFrame}>
              <View style={[styles.corner, styles.cornerTopLeft]} />
              <View style={[styles.corner, styles.cornerTopRight]} />
              <View style={[styles.corner, styles.cornerBottomLeft]} />
              <View style={[styles.corner, styles.cornerBottomRight]} />
              
              <MaterialIcons 
                name="qr-code-scanner" 
                size={120} 
                color={Colors.primary.main} 
              />
            </View>
          </View>
          
          <Text style={styles.instruction}>
            قم بتوجيه الكاميرا نحو رمز QR للدفع
          </Text>
          
          <Button
            title="بدء المسح"
            onPress={handleScan}
            variant="gradient"
            size="large"
            icon={<MaterialIcons name="camera" size={24} color={Colors.light.background} />}
          />
          
          {/* Security Info */}
          <View style={styles.securityInfo}>
            <MaterialIcons name="security" size={20} color={Colors.success} />
            <Text style={styles.securityText}>
              جميع المدفوعات محمية بتشفير من الدرجة العسكرية
            </Text>
          </View>
        </View>
      ) : (
        <View style={styles.content}>
          {/* Show QR Code */}
          <Text style={styles.instruction}>
            اطلب من العميل مسح الرمز للدفع
          </Text>
          
          <LinearGradient
            colors={Colors.primary.gradient}
            style={styles.qrCard}
          >
            <View style={styles.qrCodeContainer}>
              <MaterialIcons name="qr-code-2" size={200} color={Colors.light.background} />
            </View>
          </LinearGradient>
          
          {/* Amount Input */}
          <View style={styles.amountContainer}>
            <Text style={styles.label}>المبلغ المطلوب</Text>
            <View style={styles.inputRow}>
              <TextInput
                style={styles.input}
                placeholder="0.00"
                placeholderTextColor={Colors.light.textSecondary}
                keyboardType="decimal-pad"
                value={amount}
                onChangeText={setAmount}
              />
              <Text style={styles.currency}>ر.س</Text>
            </View>
          </View>
          
          <Button
            title="مشاركة الرمز"
            onPress={() => {}}
            variant="outline"
            icon={<MaterialIcons name="share" size={20} color={Colors.primary.main} />}
          />
        </View>
      )}
      
      {/* Success Modal */}
      <Modal
        visible={showSuccess}
        transparent
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.successCard}>
            <View style={styles.successIcon}>
              <MaterialIcons name="check-circle" size={64} color={Colors.success} />
            </View>
            <Text style={styles.successTitle}>تمت العملية بنجاح!</Text>
            <Text style={styles.successMessage}>تم الدفع بنجاح</Text>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  
  header: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.lg,
  },
  
  title: {
    fontSize: Typography.h3,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
    marginBottom: Spacing.md,
  },
  
  modeSwitch: {
    flexDirection: 'row',
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.md,
    padding: 4,
  },
  
  modeButton: {
    flex: 1,
    paddingVertical: Spacing.sm,
    alignItems: 'center',
    borderRadius: BorderRadius.sm,
  },
  
  modeButtonActive: {
    backgroundColor: Colors.primary.main,
  },
  
  modeText: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.medium,
    color: Colors.light.textSecondary,
  },
  
  modeTextActive: {
    color: Colors.light.background,
  },
  
  content: {
    flex: 1,
    padding: Spacing.md,
    gap: Spacing.lg,
  },
  
  scannerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  scannerFrame: {
    width: 280,
    height: 280,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  
  corner: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderColor: Colors.primary.main,
    borderWidth: 4,
  },
  
  cornerTopLeft: {
    top: 0,
    left: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
    borderTopLeftRadius: BorderRadius.lg,
  },
  
  cornerTopRight: {
    top: 0,
    right: 0,
    borderLeftWidth: 0,
    borderBottomWidth: 0,
    borderTopRightRadius: BorderRadius.lg,
  },
  
  cornerBottomLeft: {
    bottom: 0,
    left: 0,
    borderRightWidth: 0,
    borderTopWidth: 0,
    borderBottomLeftRadius: BorderRadius.lg,
  },
  
  cornerBottomRight: {
    bottom: 0,
    right: 0,
    borderLeftWidth: 0,
    borderTopWidth: 0,
    borderBottomRightRadius: BorderRadius.lg,
  },
  
  instruction: {
    fontSize: Typography.body1,
    color: Colors.light.textSecondary,
    textAlign: 'center',
  },
  
  qrCard: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    ...Shadows.orange,
  },
  
  qrCodeContainer: {
    backgroundColor: Colors.light.background,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    alignItems: 'center',
  },
  
  amountContainer: {
    gap: Spacing.sm,
  },
  
  label: {
    fontSize: Typography.body2,
    fontWeight: Typography.weight.medium,
    color: Colors.light.text,
  },
  
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  
  input: {
    flex: 1,
    fontSize: Typography.h4,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
    paddingVertical: Spacing.md,
  },
  
  currency: {
    fontSize: Typography.h6,
    color: Colors.light.textSecondary,
  },
  
  securityInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    padding: Spacing.md,
    backgroundColor: `${Colors.success}15`,
    borderRadius: BorderRadius.md,
  },
  
  securityText: {
    flex: 1,
    fontSize: Typography.caption,
    color: Colors.success,
  },
  
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.light.overlay,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  successCard: {
    backgroundColor: Colors.light.background,
    borderRadius: BorderRadius.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    margin: Spacing.lg,
    ...Shadows.lg,
  },
  
  successIcon: {
    marginBottom: Spacing.md,
  },
  
  successTitle: {
    fontSize: Typography.h4,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
    marginBottom: Spacing.sm,
  },
  
  successMessage: {
    fontSize: Typography.body1,
    color: Colors.light.textSecondary,
  },
});
