import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import { AIInsightCard } from '../../components/feature/AIInsightCard';
import { Card } from '../../components/ui/Card';
import { useTransactions } from '../../hooks/useTransactions';
import { AIService } from '../../services/aiService';
import { mockAIInsights } from '../../services/mockData';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';

export default function AIScreen() {
  const insets = useSafeAreaInsets();
  const { transactions } = useTransactions();
  const [insights, setInsights] = useState(mockAIInsights);
  const [predictedExpense, setPredictedExpense] = useState(0);
  
  useEffect(() => {
    // Generate AI insights
    const expenseInsights = AIService.analyzeExpenses(transactions);
    const threats = AIService.detectThreats(transactions);
    const recommendations = AIService.generateRecommendations(transactions);
    
    setInsights([...mockAIInsights, ...expenseInsights, ...threats, ...recommendations]);
    setPredictedExpense(AIService.predictExpenses(transactions));
  }, [transactions]);
  
  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>الذكاء الاصطناعي</Text>
          <Text style={styles.subtitle}>تحليلات وتوصيات ذكية</Text>
        </View>
        <LinearGradient
          colors={Colors.ai.primary}
          style={styles.aiIcon}
        >
          <MaterialIcons name="auto-awesome" size={28} color={Colors.light.background} />
        </LinearGradient>
      </View>
      
      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.contentContainer}
      >
        {/* AI Stats */}
        <View style={styles.statsGrid}>
          <Card variant="glass" style={styles.statCard}>
            <MaterialIcons name="trending-up" size={32} color={Colors.primary.main} />
            <Text style={styles.statLabel}>التوقع الشهري</Text>
            <Text style={styles.statValue}>
              {predictedExpense.toFixed(0)} ر.س
            </Text>
          </Card>
          
          <Card variant="glass" style={styles.statCard}>
            <MaterialIcons name="shield" size={32} color={Colors.success} />
            <Text style={styles.statLabel}>مستوى الأمان</Text>
            <Text style={[styles.statValue, { color: Colors.success }]}>
              ممتاز
            </Text>
          </Card>
        </View>
        
        {/* AI Features */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الميزات الذكية</Text>
          <View style={styles.featuresGrid}>
            <TouchableOpacity style={styles.featureCard}>
              <LinearGradient
                colors={['#E65100', '#FF6D00']}
                style={styles.featureIcon}
              >
                <MaterialIcons name="analytics" size={24} color={Colors.light.background} />
              </LinearGradient>
              <Text style={styles.featureTitle}>تحليل المصروفات</Text>
              <Text style={styles.featureDesc}>تتبع ذكي للإنفاق</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.featureCard}>
              <LinearGradient
                colors={['#D32F2F', '#F44336']}
                style={styles.featureIcon}
              >
                <MaterialIcons name="security" size={24} color={Colors.light.background} />
              </LinearGradient>
              <Text style={styles.featureTitle}>كشف التهديدات</Text>
              <Text style={styles.featureDesc}>حماية في الوقت الفعلي</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.featureCard}>
              <LinearGradient
                colors={['#7C4DFF', '#9C27B0']}
                style={styles.featureIcon}
              >
                <MaterialIcons name="lightbulb" size={24} color={Colors.light.background} />
              </LinearGradient>
              <Text style={styles.featureTitle}>توصيات ذكية</Text>
              <Text style={styles.featureDesc}>نصائح مالية مخصصة</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.featureCard}>
              <LinearGradient
                colors={['#00C853', '#4CAF50']}
                style={styles.featureIcon}
              >
                <MaterialIcons name="savings" size={24} color={Colors.light.background} />
              </LinearGradient>
              <Text style={styles.featureTitle}>خطة التوفير</Text>
              <Text style={styles.featureDesc}>هدف مالي ذكي</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* AI Insights */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>التحليلات الذكية</Text>
          <View style={styles.insightsList}>
            {insights.map(insight => (
              <AIInsightCard key={insight.id} insight={insight} />
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.lg,
  },
  
  title: {
    fontSize: Typography.h3,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  subtitle: {
    fontSize: Typography.body2,
    color: Colors.light.textSecondary,
    marginTop: 4,
  },
  
  aiIcon: {
    width: 56,
    height: 56,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  content: {
    flex: 1,
  },
  
  contentContainer: {
    padding: Spacing.md,
    gap: Spacing.lg,
  },
  
  statsGrid: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  
  statCard: {
    flex: 1,
    alignItems: 'center',
    gap: Spacing.sm,
  },
  
  statLabel: {
    fontSize: Typography.caption,
    color: Colors.light.textSecondary,
    textAlign: 'center',
  },
  
  statValue: {
    fontSize: Typography.h5,
    fontWeight: Typography.weight.bold,
    color: Colors.primary.main,
  },
  
  section: {
    gap: Spacing.md,
  },
  
  sectionTitle: {
    fontSize: Typography.h5,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
  },
  
  featureCard: {
    width: '48%',
    backgroundColor: Colors.light.surfaceElevated,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  featureTitle: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  featureDesc: {
    fontSize: Typography.caption,
    color: Colors.light.textSecondary,
  },
  
  insightsList: {
    gap: Spacing.md,
  },
});
