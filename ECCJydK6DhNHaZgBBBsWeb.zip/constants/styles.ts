import { StyleSheet } from 'react-native';
import { Colors, Typography, Spacing, BorderRadius, Shadows } from './theme';

export const CommonStyles = StyleSheet.create({
  // Container Styles
  container: {
    flex: 1,
  },
  
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  // Card Styles
  card: {
    backgroundColor: Colors.light.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    ...Shadows.md,
  },
  
  glassCard: {
    backgroundColor: Colors.light.glass,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  
  // Text Styles
  h1: {
    fontSize: Typography.h1,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  h2: {
    fontSize: Typography.h2,
    fontWeight: Typography.weight.bold,
    color: Colors.light.text,
  },
  
  h3: {
    fontSize: Typography.h3,
    fontWeight: Typography.weight.semibold,
    color: Colors.light.text,
  },
  
  body1: {
    fontSize: Typography.body1,
    fontWeight: Typography.weight.regular,
    color: Colors.light.text,
  },
  
  body2: {
    fontSize: Typography.body2,
    fontWeight: Typography.weight.regular,
    color: Colors.light.textSecondary,
  },
  
  caption: {
    fontSize: Typography.caption,
    fontWeight: Typography.weight.regular,
    color: Colors.light.textSecondary,
  },
  
  // Button Styles
  button: {
    borderRadius: BorderRadius.md,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.lg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  primaryButton: {
    backgroundColor: Colors.primary.main,
  },
  
  // Layout
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  
  spaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
