// OrangePay Design System - Premium Financial Theme

export const Colors = {
  // Primary Orange Palette
  primary: {
    main: '#E65100',        // Deep Orange
    light: '#FF6D00',       // Vibrant Orange
    dark: '#BF360C',        // Dark Orange
    gradient: ['#E65100', '#FF6D00', '#FF8F00'],
  },
  
  // Semantic Colors
  success: '#00C853',
  warning: '#FFB300',
  error: '#D32F2F',
  info: '#0288D1',
  
  // AI Colors
  ai: {
    primary: ['#7C4DFF', '#9C27B0'],
    secondary: '#536DFE',
    accent: '#FF4081',
  },
  
  // Light Theme
  light: {
    background: '#FFFFFF',
    surface: '#F5F5F5',
    surfaceElevated: '#FFFFFF',
    text: '#212121',
    textSecondary: '#757575',
    border: '#E0E0E0',
    overlay: 'rgba(0, 0, 0, 0.5)',
    glass: 'rgba(255, 255, 255, 0.85)',
    cardGradient: ['#FFFFFF', '#FAFAFA'],
  },
  
  // Dark Theme
  dark: {
    background: '#0A0A0A',
    surface: '#1A1A1A',
    surfaceElevated: '#2A2A2A',
    text: '#FFFFFF',
    textSecondary: '#B0B0B0',
    border: '#333333',
    overlay: 'rgba(0, 0, 0, 0.7)',
    glass: 'rgba(26, 26, 26, 0.85)',
    cardGradient: ['#1A1A1A', '#0A0A0A'],
  },
};

export const Typography = {
  // Font Families
  regular: 'System',
  medium: 'System',
  bold: 'System',
  
  // Font Sizes
  h1: 32,
  h2: 28,
  h3: 24,
  h4: 20,
  h5: 18,
  h6: 16,
  body1: 16,
  body2: 14,
  caption: 12,
  button: 16,
  
  // Line Heights
  lineHeight: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
  
  // Font Weights
  weight: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const BorderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const Shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 8,
  },
  orange: {
    shadowColor: '#E65100',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
};

export const Animation = {
  duration: {
    fast: 200,
    normal: 300,
    slow: 500,
  },
  easing: {
    standard: 'ease-in-out',
    decelerate: 'ease-out',
    accelerate: 'ease-in',
  },
};
